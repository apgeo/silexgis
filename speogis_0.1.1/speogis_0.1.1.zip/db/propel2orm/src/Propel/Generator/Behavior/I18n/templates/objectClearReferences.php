$this->currentLocale = '<?= $defaultLocale ?>';
$this->currentTranslations = null;
