
/**
 * Current locale
 * @var        string
 */
protected $currentLocale = '<?= $defaultLocale ?>';

/**
 * Current translation objects
 * @var        array[<?= $objectClassName ?>]
 */
protected $currentTranslations;
