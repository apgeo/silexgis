
/**
 * The default locale to use for translations.
 *
 * @var string
 */
const DEFAULT_LOCALE = '<?= $defaultLocale ?>';
