propel.database.connections.default.adapter: <?php echo $rdbms . PHP_EOL ?>
propel.database.connections.default.dsn: <?php echo $dsn . PHP_EOL ?>
propel.database.connections.default.user: <?php echo $user . PHP_EOL ?>
propel.database.connections.default.password: <?php echo $password . PHP_EOL ?>
propel.database.connections.default.settings.charset: <?php echo $charset . PHP_EOL ?>
