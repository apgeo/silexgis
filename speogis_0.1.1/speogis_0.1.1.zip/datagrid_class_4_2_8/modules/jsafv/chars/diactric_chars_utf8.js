var diac_lwr="";
var diac_upr="";
