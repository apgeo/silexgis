INSERT into surveys values ( 1, "fara_manifest", "2026.10.20", "", 0.00, "", "" );
